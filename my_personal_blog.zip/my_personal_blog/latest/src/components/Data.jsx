export const memoirs = [
    {
        image :"https://images.squarespace-cdn.com/content/v1/5cd9be5ac46f6d08fa657d15/1572641369150-Y1R1NSP7DU5R2N5MIZ2Z/Acting+Curtain+Shot.jpg",
        title : "My passion for acting",
    },
    {
        image:"https://t4.ftcdn.net/jpg/06/53/21/11/240_F_653211122_FheyGVvJb5RGWkXYeN7XRIobmVFcoG6K.jpg",
        title : "Avid Coder",
    },
    {
        image : "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRO6PetTgeLolSR7VijAiczyH6HQ1Xusz_A5A&usqp=CAU",
        title : "Where Booksmarts meet Streetsmarts",
    },
 
 
];