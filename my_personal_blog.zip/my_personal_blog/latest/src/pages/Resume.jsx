import React from 'react';
import NavBar from '../navigate/NavBar';
import ResumeSection from '../components/ResumeSection';
import ResumeSection2 from '../components/ResumeSection2';
const Resume = () => {
  return (
    <div className='nav-app'>
      <NavBar/>
     
      <div className='resume-swipe'><ResumeSection/></div>
      <div className='resume-swipe2'><ResumeSection2/></div>

    </div>
  );
};

export default Resume;