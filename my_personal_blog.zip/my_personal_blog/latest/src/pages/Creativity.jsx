import React from 'react';
import NavBar from '../navigate/NavBar';
const Creativity = () => {
  return (
    <div className='nav-app'>
     <NavBar/>
     <p>Now that you're here, I'm revealing the depth of creativity and how much it means to me in every aspect. I love to be creative about people psychology, how in a social setting one chooses to handle friendships,
       how one chooses to approach to solve conflicts, ground reality facts of human nature 
      and how its uncomfortable sides can be overcame and not to miss out on the important weapon - the psychological tricks that get one to move forward conquering every negativity to being courageous and resilient enough to protect oneself. Feel free to check out an article I had written on Personality and prediction of behaviour in a work-setting.</p>

      <p>Next aspect is in terms of coding, I have always wondered if there's a way to reduce the aftermath of artifical intelligence posing a major threat, it is very integral to find a way to fix the limits to avoid crossing the "privacy-invasion" and "limitless scamming" threshold. One solution that I'll propose will be published shortly.To be able to come up with a solution, I'm making my way towards trying to understand the basis of the statistical computing and what it costs for the major difference reflected in results. 
        My admiration about quantum computing has also been keeping me in the zone of exploration for a possibilty to outweigh artifical intelligence.</p>

        <p>This is a fun topic that I'm choosing to end with - acting!</p>

      
    </div>

  );
};

export default Creativity;